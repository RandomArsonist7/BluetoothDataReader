package com.example.workpls

import ConnectedThread
import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.runtime.remember

class MainActivity : ComponentActivity() {
    private val TAG = "FrugalLogs"

    // Define your permissions
    private val BLUETOOTH_PERMISSIONS = arrayOf(
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.BLUETOOTH,
        Manifest.permission.BLUETOOTH_ADMIN,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    )

    private val REQUEST_ENABLE_BT = 1
    private var arduinoBTModule: BluetoothDevice? = null
    private var arduinoUUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private lateinit var bluetoothPermissionLaunchers: List<ActivityResultLauncher<String>>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize the list of permission launchers
        bluetoothPermissionLaunchers = BLUETOOTH_PERMISSIONS.map { permission ->
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
                if (isGranted) {
                    Log.d(TAG, "$permission granted")
                } else {
                    Log.d(TAG, "$permission denied")
                }
            }
        }

        // Check and request all permissions
        checkPermissions()
    }

    private fun checkPermissions() {
        var allPermissionsGranted = true

        for (permission in BLUETOOTH_PERMISSIONS) {
            if (ActivityCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false
                // Launch the permission request
                bluetoothPermissionLaunchers[BLUETOOTH_PERMISSIONS.indexOf(permission)].launch(permission)
            }
        }

        if (allPermissionsGranted) {
            // Proceed with Bluetooth operations
            Log.d(TAG, "All Bluetooth permissions are granted")
            initBluetooth() // Initialize Bluetooth operations
        }
    }

    private fun initBluetooth() {
        setContent {
            BluetoothApp()
        }
    }

    @Composable
    fun BluetoothApp() {
        var btReadings by remember { mutableStateOf("") } // State variable to hold Bluetooth readings
        var btDevices by remember { mutableStateOf(listOf<BluetoothDevice>()) } // List of Bluetooth devices

        val bluetoothAdapter = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Text(text = "Bluetooth Readings: $btReadings")

            // List of paired devices
            LazyColumn {
                items(btDevices) { device ->
                    // Make each device clickable
                    if (ActivityCompat.checkSelfPermission(this@MainActivity, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                        // Skip listing devices if permission is not granted
                        return@items
                    }
                    Text(
                        text = "${device.name} || ${device.address}",
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                // Handle device click
                                arduinoBTModule = device // Set the selected device
                                connectToDevice { value ->
                                    // Update btReadings here when a value is received
                                    btReadings = value // Assuming value is the new reading
                                } // Pass a lambda to connectToDevice
                            }
                            .padding(8.dp)
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(onClick = {
                    btReadings = "" // Clear values
                }) {
                    Text("Clear Values")
                }
                Button(onClick = {
                    val devices = searchPairedDevices(bluetoothAdapter)
                    btDevices = devices // Update the list of devices
                }) {
                    Text("Search Devices")
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun connectToDevice(onValueReceived: (String) -> Unit) { // Take a callback
        CoroutineScope(Dispatchers.IO).launch {
            val handler = Handler(Looper.getMainLooper())

            arduinoBTModule?.let { device ->
                val connectThread = ConnectThread(device, arduinoUUID, handler, this@MainActivity)
                connectThread.start()
                connectThread.join() // Wait for the thread to finish

                val socket = connectThread.getMmSocket() // Access the socket after connectThread has finished
                if (socket?.isConnected == true) {
                    Log.d(TAG, "Socket connected successfully")
                    // Show a Toast message for successful connection
                    handler.post {
                        Toast.makeText(this@MainActivity, "Connected to ${device.name}", Toast.LENGTH_SHORT).show()
                    }

                    val connectedThread = ConnectedThread(socket)
                    connectedThread.start()

                    // Continuously read values
                    while (true) {
                        val valueRead = connectedThread.valueRead // Replace with your reading logic
                        withContext(Dispatchers.Main) {
                            // Call the onValueReceived callback to update btReadings
                            onValueReceived(valueRead ?: "No readings")
                        }
                    }
                } else {
                    Log.e(TAG, "Socket not connected")
                    // Show a Toast message for failed connection
                    handler.post {
                        Toast.makeText(this@MainActivity, "Connection failed", Toast.LENGTH_SHORT).show()
                    }
                }
                connectThread.cancel()
            } ?: run {
                Log.e(TAG, "Bluetooth device is not available")
                // Show a Toast message for unavailable device
                handler.post {
                    Toast.makeText(this@MainActivity, "Bluetooth device is not available", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun searchPairedDevices(bluetoothAdapter: BluetoothAdapter): List<BluetoothDevice> {
        val devicesList = mutableListOf<BluetoothDevice>()

        if (bluetoothAdapter == null) {
            Log.d(TAG, "Device doesn't support Bluetooth")
            return devicesList // Return an empty list
        }

        // Check if Bluetooth is enabled
        if (!bluetoothAdapter.isEnabled) {
            // Request to enable Bluetooth
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)
            return devicesList // Return an empty list
        }

        // Check permissions before accessing paired devices
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            Log.d(TAG, "Bluetooth connect permission is not granted")
            // Optionally, show a message to the user that permission is required
            return devicesList // Return an empty list
        }

        // Get paired devices
        val pairedDevices = bluetoothAdapter.bondedDevices
        pairedDevices.forEach { device ->
            Log.d(TAG, "Found device: ${device.name} with address ${device.address}")
            devicesList.add(device) // Add each device to the list
        }

        return devicesList // Return the list of Bluetooth devices
    }
}




